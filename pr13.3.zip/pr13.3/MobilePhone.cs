﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr13._2bel
{
    class MobilePhone
    {
        public MobilePhone(string model, string raskras, double screen, int pamob, int pamop){}
        public string model;
        public string raskras;
        public double screen = 0;
        public int pamob = 0;
        public int pamop = 0;
        public void setModel(string model)
        {
            this.model = model;
        }
        public string getModel()
        {
            return model;
        }
        public void setRaskras(string raskras)
        {
            this.raskras = raskras;
        }
        public string getRaskras()
        {
            return raskras;
        }
        public void setScreen(double screen)
        {
            this.screen = screen;
        }
        public double getScreen()
        {
            return screen;
        }
        public void setPamob(int pamob)
        {
            this.pamob = pamob;
        }
        public int getPamob()
        {
            return pamob;
        }
        public void setPamop(int pamop)
        {
            this.pamop = pamop;
        }
        public int getPamop()
        {
            return pamop;
        }
    }
}
